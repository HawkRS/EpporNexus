
jQuery = window.$;

// Función principal que maneja la lógica de visualización y el atributo 'required'.
// Cuando se llama por el evento 'change', 'this' es el elemento <select id="datosenvio">.
const toggleDisplay = function() {
    // Si la función se llama desde un evento jQuery delegado, 'this' será el elemento <select>.
    const selectElement = (this && this.id === 'datosenvio')
        ? this
        : document.getElementById('datosenvio');

    if (!selectElement) return;

    // Usamos el método jQuery .val() para la extracción más confiable del valor.
    const selectValue = $(selectElement).val();
    const otrosDiv = document.getElementById('datosenviootros');
    const campos = otrosDiv ? otrosDiv.querySelectorAll('input') : [];

    // Convertimos el elemento DOM a un objeto jQuery para manipular Bootstrap Collapse
    const $otrosDiv = $(otrosDiv);

    if (!$otrosDiv.length) return; // Verificamos si el elemento existe

    // Check for value '2'
    if (selectValue === '2') {
        console.log('mostrando (COLLAPSE). Valor seleccionado:', selectValue);

        // **ACCIÓN COLLAPSE: Usar el método 'show' de Bootstrap**
        $otrosDiv.collapse.show;

        // Añadir 'required' para validación cuando está visible
        campos.forEach(input => input.setAttribute('required', 'required'));
    } else {
        console.log('ocultando (COLLAPSE). Valor seleccionado:', selectValue);

        // **ACCIÓN COLLAPSE: Usar el método 'hide' de Bootstrap**
        $otrosDiv.collapse;

        // Eliminar 'required' cuando está oculto
        campos.forEach(input => input.removeAttribute('required'));
    }
};
    const confirmModal = document.getElementById('confirmActionModal');

$(document).ready(function () {
    if (bolsaerrores.length > 0) {

        // 2. Usamos el selector del modal que contiene los errores y lo mostramos.
        // ADVERTENCIA: Debes asegurarte de que el div principal del modal tenga el ID #errorModal
        jQuery('#errorModal').modal('show');

    }
    const modalId = '#PaqueteriaModal';

    // 1. Delegación de Eventos (Método Robusto):
    $(modalId).on('change', '#datosenvio', toggleDisplay);


    // 2. Inicialización del Estado al Abrir el Modal:
    $(modalId).on('shown.bs.modal', function () {
        // Ejecutamos la función una vez al abrir el modal para establecer el estado inicial
        // Esto también asegura que si ya estaba en el estado 'collapse show', se ajuste.
        toggleDisplay();
    });

    // 3. Fallback: Inicialización directa (solo si el modal NO existe en el DOM al cargar la página)
    const selectEnvioReady = document.getElementById('datosenvio');
    const otrosDivReady = document.getElementById('datosenviootros');

    if (selectEnvioReady && otrosDivReady && !$(modalId).length) {
        toggleDisplay();
        $(document).on('change', '#datosenvio', toggleDisplay);
    }

    $('.editPagoBtn').on('click', function(e) {
        // Capturamos el botón que fue clickeado
        let $btn = $(this);
        let id = $btn.data('id');

        // 1. Definir la URL de actualización (Asumiendo que 'route()' es una función global de Laravel/Ziggy)
        // Si no usas Ziggy, cambia esto por la ruta manual, ej: `/pagos/${id}`
        let editUrl = window.route ? route('pagos.update', id) : `/pagos/${id}`;

        // 2. Establecer la URL de acción del formulario
        $('#editPagoForm').attr('action', editUrl);

        // 3. Cargar los datos a los campos del modal
        $('#editFecha').val($btn.data('fecha'));
        $('#editMetodo').val($btn.data('metodo'));
        $('#editBanco').val($btn.data('banco'));
        $('#editMonto').val($btn.data('monto'));

        console.log('Modal de edición de pago cargado. ID:', id, 'URL:', editUrl);
    });


    if (confirmModal) {
        confirmModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget; // Botón que activó el modal

            // Extraer info de los atributos data-
            const nombre = button.getAttribute('data-nombre');
            const actionUrl = button.getAttribute('data-action-url'); // La ruta completa de Laravel
            const type = button.getAttribute('data-type');

            // Elementos del modal
            const form = document.getElementById('actionForm');
            const title = document.getElementById('actionTitle');
            const message = document.getElementById('actionMessage');
            const confirmBtn = document.getElementById('confirmActionBtn');
            const header = document.getElementById('modalHeaderColor');
            const methodPlaceholder = document.getElementById('methodPlaceholder');

            // Asignar la URL directamente (Laravel ya incluyó el localhost/proyecto/public)
            form.action = actionUrl;

            if (type === 'eliminar') {
                title.innerText = 'Eliminar Pedido';
                message.innerHTML = `¿Realmente deseas borrar permanentemente el <b>${nombre}</b>?`;
                header.className = 'modal-header bg-danger text-white';
                confirmBtn.className = 'btn btn-danger px-4';
                methodPlaceholder.innerHTML = ''; // Tu ruta es POST según lo que enviaste
            } else {
                title.innerText = 'Anular Pedido';
                message.innerHTML = `¿Marcar el <b>${nombre}</b> como anulado?`;
                header.className = 'modal-header bg-warning text-dark';
                confirmBtn.className = 'btn btn-warning px-4 text-dark';
                // Si la ruta de cancelar es PATCH o PUT, lo agregamos aquí:
                methodPlaceholder.innerHTML = '<input type="hidden" name="_method" value="post">';
            }
        });
    }


});
